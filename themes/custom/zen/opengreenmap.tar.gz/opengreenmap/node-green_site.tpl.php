<?php
// get all the Icon/taxonomy information

// get the primary term
$primary_term_tid = $node->primary_term->tid;
$primary_term_name = $node->primary_term->name; // we'll use this visible on the page
$icons = taxonomy_image_display($primary_term_tid, "alt='$primary_term_name'");
$categories = taxonomy_get_parents($primary_term_tid);
foreach ($categories as $category){
	$genres = taxonomy_get_parents($category->tid);
}
if ($genres){
	foreach ($genres as $genre){
		$genre_name_lc = strtolower($genre->name);
	}
}
// get all other terms
foreach($node->taxonomy as $key => $value) {
	if($key != $primary_term_tid){
		$icons .= taxonomy_image_display($key);
	}
}
?>

<div id="node-<?php print $node->nid; ?>" class="node<?php if ($sticky) { print ' sticky'; } ?><?php if (!$status) { print ' node-unpublished'; } ?> <?php print $node_classes . ' ' . $genre_name_lc ?> clear-block">


<?php if ($page == 0): ?>
  <h2><a href="<?php print $node_url ?>" title="<?php print $title ?>"><?php print $title ?></a></h2>
<?php endif; ?>





<div id="address">
	<?php if ($location[name] > '') { ?>
		<div class="location name"> <?php print $location[name]; ?> </div>
	<?php } ?>
	<?php if ($location[street] > '') { ?>
		<div class="location street"> <?php print $location[street]; ?> </div>
	<?php } ?>
	<?php if ($location[additional] > '') { ?>
		<div class="location additional"> <?php print $location[additional]; ?> </div>
	<?php } ?>
	<?php if ($location[city] > '') { ?>
		<div class="location city"> <?php print $location[city]; ?> </div>
	<?php } ?>
	<?php if ($location[postal_code] > '' || $location[province] > '') { ?>
		<div class="location postalcode"> 
			<?php print $location[province] . ' ' . $location[postal_code]; ?> 
			<a href="#tabs-tabs-2"><img src="<?php print base_path() . path_to_subtheme(); ?>/images/green_arrow.png" alt="Get directions"></a>
		</div>
	<?php } ?>

	<?php if ($field_phone[0] > '') { ?>
		<div class="fieldphone"> <?php print content_format('field_phone', $field_phone[0]); ?> </div>
	<?php } ?>
	<?php if ($field_email[0] > '') { ?>
		<div class="fieldemail"> <?php print content_format('field_email', $field_email[0]); ?> </div>
	<?php } ?>
	<?php if ($field_web[0] > '') { ?>
		<div class="fieldweb"> <?php print content_format('field_web', $field_web[0]); ?> </div>
	<?php } ?>
</div>


<h2 class="icontitle"><?php print $title; ?></h2>

<div class="taximage">
	<?php print $icons; ?>
</div>
<div class="taxname">
	<?php print $primary_term_name; ?>
</div>

  <?php
  // prepare content for MAIN tab
  if($node->field_video[0]['value'] > '') {
  	$media_thumb = theme('video_cck_video_thumbnail', $node->field_video, $node->field_video[0], 'video_thumbnail', $node);
  } elseif($node->field_image[0]['value'] > '') {
  	$media_thumb = theme('image_ncck_image_thumbnail', $node->field_image, $node->field_image[0], 'image_thumbnail', $node);
  }
  $contents = '<div id="mediathumbs">' . $media_thumb . '</div>'; 
  $contents .= content_format('field_details', $field_details[0]);
  
  // prepare content for COMMENT tab
  $comments = comment_render($node);
  if($node->comment_count == 0) {
  	$comments = '<p>' . t('0 comments') . '</p>';	
  } else {
  	$comments = '<p>' . comment_render($node) . '</p>';
  }
  // add a comment link
  $comments .= '<p>' . l(t('Add new comment'),'comment/reply/' . $node->nid , NULL, 'theme=simple', 'comment-form') . '</p>'; // should add an 'if' to remove '/simple' when not in simple mode (bubble)
  
  // prepare content for CONNECTIONS tab  
  // get directions
  $connections = $node->field_public_transport_directio[0]['view']; // already comes with some <p> tags
  if ($connections > '') {
  	// if there are directions, give it a header
	$connections = '<h3>' . t('Directions') . '</h3>' . $connections;
  }
  // what else to put here?
  $connections .= '<h3>' . t('More Connections') . '</h3>';
  $connections .= '<p>' . t('Soon you will be able to suggest links to be added here, as well as finding links to other similar sites locally and around the world.') . '</p>';
  
  // prepare content for the MEDIA tab
  if(content_format('field_image', $field_image[0]) > '') {
  	foreach ($field_image as $item) { 
    	$images .= content_format('field_image', $item);
	} 
  }
  if(content_format('field_video', $field_video[0]) > '') {
  	foreach ($field_video as $item) { 
    	$videos .= content_format('field_video', $item); 
	} 
  }  
  if($images > '' || $videos > '') {
  	$multimedia = $images . $videos;
  }
  
  // prepare content for the IMPACTS tab
  // what goes here? A content creation form? With a link to view results?
  // a poll? that would be easiest... can a poll be linked to the node?
  $impacts = '<p>' . t('In the future we will be gathering information about the impacts that this site has on your life.') . '</p>';
  

  // this sets up the tabs for the page

  $form = array();

  $form['tabs'] = array(
    '#type' => 'tabset',
  );
  $form['tabs']['tab1'] = array(
    '#type' => 'tabpage',
    '#title' => t('Overview'),
	'#weight' => '-6',
    '#content' => $contents, 
  );
  // theme('comment_wrapper') pulls in comments formatted in template.php, though it doesn't work. comment_render($node) does work but it shows up twice.
  $form['tabs']['tab2'] = array(
    '#type' => 'tabpage',
    '#title' => t('Comments'),
	'#weight' => '-4',
    '#content' => '<div class="mycomments">'  . $comments . '</div>', 
  );
  $form['tabs']['tab3'] = array(
    '#type' => 'tabpage',
    '#title' => t('Connections'),
	'#weight' => '-2',
    '#content' => '<div class="connections">'  . $connections . '</div>',
  );
if($multimedia) {  
  $form['tabs']['tab4'] = array(
    '#type' => 'tabpage',
    '#title' => t('Multimedia'),
	'#weight' => '0',
    '#content' => '<div class="multimedia">'  . $multimedia . '</div>',
  );
}
  $form['tabs']['tab5'] = array(
    '#type' => 'tabpage',
    '#title' => t('Impacts'),
	'#weight' => '2',
    '#content' => '<div class="impacts">'  . $impacts . '</div>',
  );

  print tabs_render($form);
?>



<div id="siteactions">
	<ul>
		<li><?php print format_plural($comment_count, '1 comment', '@count comments'); ?></li>
		<li><?php print l(t('share this site'), 'forward/' . $node->nid . '/simple'); ?></li>
		<li><?php print l(t('flag this'),'abuse/report/node/' . $node->nid . '/simple'); ?></li>
	</ul>
</div>

<?php // insert the icons for free, youth-friendly, accessible, etc. 
if($node->field_accessible_by_public_tran[0]['value'] == 1) { 
	$siteicons .= '<li>' . '<img src="' . base_path() . path_to_subtheme() . '/images/accessible.png" alt="' . t('accessible') . '">' . '</li>';
}
if($node->field_child_friendly[0]['value'] == 1) { 
	$siteicons .= '<li>' . '<img src="' . base_path() . path_to_subtheme() . '/images/youth.png" alt="' . t('youth friendly') . '">' . '</li>';
}
if($node->field_appointment_needed[0]['value'] == 1) { 
	$siteicons .= '<li>' . '<img src="' . base_path() . path_to_subtheme() . '/images/appointment.png" alt="' . t('appointment necessary - call first') . '">' . '</li>';
}
if($node->field_accessible_by_public_tran[0]['value'] == 1) { 
	$siteicons .= '<li>' . '<img src="' . base_path() . path_to_subtheme() . '/images/transport.png" alt="' . t('accessible by public transport') . '">' . '</li>';
}
if($node->field_free_entry[0]['value'] == 1) { 
	$siteicons .= '<li>' . '<img src="' . base_path() . path_to_subtheme() . '/images/free.png" alt="' . t('free entry') . '">' . '</li>';
}
?>
<div id="iconsandstars">
	<?php 
	
	if($siteicons > '') { ?>
		
		<div class="siteicons">
			<ul class="links">
				<?php print $siteicons; ?>
			</ul>
		</div>
		
	<?php } ?>
	
	<div class="fivestar">
		<?php
		$fivestarwidget = fivestar_widget_form($node);
		print $fivestarwidget;
		?>
	</div>


</div>

<div class="meta">
	<span class="submitted">
		<img src="<?php print base_path() . path_to_theme() . '/img/mapper.gif' ?>" width="20px" height="19px" 
		alt="<?php print t('added') . date('m/Y', $node->created) . t('by') . $node->name; ?>" />
		<?php print t('added') . ' ' . date('m/Y', $node->created) . ' ' . t('by') . ' ' . l($node->name,'user/' . $node->uid) . ' '; ?>
		<?php 
		if($node->og_groups_names[0] > '') {
			print t('to') . ' ' . l($node->og_groups_names[0],'node/'.$node->og_groups[0]);
		}
		?>
	</span>
</div>


<?php 
  /* if ($links) {
    print $links;
  } */
 ?>

<pre>
<?php
//	print_r($node); // output all data for theming 
?>
</pre>


</div>